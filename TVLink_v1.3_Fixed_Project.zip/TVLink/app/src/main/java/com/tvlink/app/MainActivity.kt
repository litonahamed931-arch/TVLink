package com.tvlink.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import fi.iki.elonen.NanoHTTPD
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.SecureRandom
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val io = Executors.newSingleThreadExecutor()
    private var server: TvHttpServer? = null
    private var nsd: NsdManager? = null
    private var registration: NsdManager.RegistrationListener? = null
    private var discovery: NsdManager.DiscoveryListener? = null
    private var lock: WifiManager.MulticastLock? = null
    private var foundHost: String? = null
    private var foundPort = 8765
    private var pairedHost: String? = null
    private var pairedPort = 8765
    private var role = "home"

    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var ipInput: EditText
    private lateinit var codeInput: EditText
    private lateinit var scanButton: Button
    private lateinit var videoButton: Button
    private lateinit var pairing: PairingState
    private var tvStatus: TextView? = null
    private var tvVideo: VideoView? = null
    private var tvVideoFile: File? = null

    companion object {
        private const val PICK_VIDEO_REQUEST = 4102
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        nsd = getSystemService(Context.NSD_SERVICE) as NsdManager
        home()
    }

    private fun home() {
        role = "home"
        root = column()
        root.addView(label("TVLink", 32f, true))
        root.addView(label("Pair your Android phone and TV Box on the same Wi-Fi network.", 17f))
        root.addView(button("TV Box mode — show pairing code") { startTv() })
        root.addView(button("Android Controller — find TV") { controller() })
        root.addView(label("Open TV Box mode on your TV first. Then connect your phone using the code shown on TV.", 13f))
        showPage()
    }

    private fun startTv() {
        stopNetwork()
        role = "tv"
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val code = String.format(Locale.US, "%06d", SecureRandom().nextInt(1_000_000))
        pairing = PairingState(code)

        try {
            server = TvHttpServer(
                8765,
                pairing,
                assets,
                cacheDir,
                onVideoReceived = { file ->
                    runOnUiThread { playReceivedVideo(file) }
                },
                onControl = { action ->
                    runOnUiThread { handleTvControl(action) }
                }
            ).also {
                it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
            }
            registerService(8765)

            root = column()
            root.addView(label("TVLink · TV Box", 28f, true))
            root.addView(label("Enter this code on your phone:", 17f))
            root.addView(label("${code.take(3)} ${code.drop(3)}", 44f, true))
            root.addView(label("TV IP: ${localIp()}  ·  Port: 8765", 16f))

            tvStatus = label("Status: waiting for phone connection", 17f)
            root.addView(tvStatus)

            tvVideo = VideoView(this).apply {
                setBackgroundColor(android.graphics.Color.BLACK)
                isFocusable = true
                isFocusableInTouchMode = true
                setOnErrorListener { _, what, extra ->
                    tvStatus?.text = "Video playback error ($what / $extra). Try another video format."
                    true
                }
                setOnPreparedListener { player ->
                    player.isLooping = false
                    start()
                    requestFocus()
                    tvStatus?.text = "Playing video"
                }
                setOnCompletionListener {
                    tvStatus?.text = "Video finished"
                }
            }
            root.addView(
                tvVideo,
                LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    0,
                    1f
                )
            )

            val controls = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            fun addTvControl(text: String, action: () -> Unit) {
                val control = button(text, action)
                controls.addView(control, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = 4
                    marginEnd = 4
                })
            }
            addTvControl("Play") { tvVideo?.start() }
            addTvControl("Pause") { if (tvVideo?.isPlaying == true) tvVideo?.pause() }
            addTvControl("Stop") { stopTvVideo() }
            root.addView(controls)
            root.addView(label("Keep TVLink open while sending videos from your phone.", 13f))
            root.addView(button("Back") {
                stopNetwork()
                home()
            })
            showTvPage()

            android.os.Handler(mainLooper).postDelayed(object : Runnable {
                override fun run() {
                    if (role == "tv" && !isFinishing) {
                        val videoState = tvStatus?.text?.toString().orEmpty()
                        if (videoState.startsWith("Status:")) {
                            tvStatus?.text = if (pairing.paired) {
                                "Status: phone connected ✓"
                            } else {
                                "Status: waiting for phone connection"
                            }
                        }
                        android.os.Handler(mainLooper).postDelayed(this, 1000)
                    }
                }
            }, 1000)

        } catch (e: Exception) {
            errorScreen("Could not start receiver: ${e.message}")
        }
    }

    private fun playReceivedVideo(file: File) {
        if (role != "tv" || !file.exists()) return
        tvVideoFile = file
        tvStatus?.text = "Video received: ${file.name}"
        tvVideo?.setVideoURI(Uri.fromFile(file))
        tvVideo?.requestFocus()
    }

    private fun stopTvVideo() {
        try {
            tvVideo?.stopPlayback()
            tvStatus?.text = "Playback stopped"
        } catch (_: Exception) {}
    }

    private fun handleTvControl(action: String) {
        when (action) {
            "play" -> {
                if (tvVideoFile?.exists() == true) tvVideo?.start()
            }
            "pause" -> if (tvVideo?.isPlaying == true) tvVideo?.pause()
            "stop" -> stopTvVideo()
        }
    }

    private fun controller() {
        role = "controller"
        pairedHost = null
        root = column()

        root.addView(label("TVLink Controller", 28f, true))
        status = label("Ready. Start TV Box mode on your TV, then tap Scan.", 16f)
        root.addView(status)

        scanButton = button("Scan for TVs") { discover() }
        root.addView(scanButton)

        root.addView(label("If discovery does not work, enter the TV IP address shown on the TV screen.", 13f))

        ipInput = EditText(this).apply {
            hint = "TV IP address (e.g. 192.168.1.20)"
            isSingleLine = true
            setText(foundHost ?: "")
            setTextColor(android.graphics.Color.BLACK)
            setHintTextColor(android.graphics.Color.DKGRAY)
            setBackgroundColor(android.graphics.Color.WHITE)
            setPadding(16, 14, 16, 14)
        }
        root.addView(ipInput)

        codeInput = EditText(this).apply {
            hint = "6-digit TV code"
            isSingleLine = true
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(android.text.InputFilter.LengthFilter(6))
            setTextColor(android.graphics.Color.BLACK)
            setHintTextColor(android.graphics.Color.DKGRAY)
            setBackgroundColor(android.graphics.Color.WHITE)
            setPadding(16, 14, 16, 14)
        }
        root.addView(codeInput)

        root.addView(button("Connect") {
            val host = ipInput.text.toString().trim()
            val code = codeInput.text.toString().trim()

            if (host.isBlank() || !code.matches(Regex("\\d{6}"))) {
                status.text = "Enter the TV IP and a 6-digit code."
            } else {
                pair(host, code)
            }
        })

        videoButton = button("Choose video from phone") { chooseVideo() }.apply {
            isEnabled = false
        }
        root.addView(videoButton)

        val remoteControls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
        }
        remoteControls.addView(button("Play / Resume") { sendControl("play") })
        remoteControls.addView(button("Pause") { sendControl("pause") })
        remoteControls.addView(button("Stop") { sendControl("stop") })
        root.addView(remoteControls)

        root.addView(button("Back") {
            stopDiscovery()
            home()
        })

        showPage()
    }

    private fun discover() {
        stopDiscovery()
        status.text = "Searching for TVLink receivers…"
        scanButton.isEnabled = false
        foundHost = null

        try {
            val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            lock = wifi.createMulticastLock("TVLinkDiscovery").apply {
                setReferenceCounted(false)
                acquire()
            }

            discovery = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(type: String) {}

                override fun onServiceFound(service: NsdServiceInfo) {
                    if (service.serviceType.contains("_tvlink._tcp")) {
                        nsd?.resolveService(service, object : NsdManager.ResolveListener {
                            override fun onResolveFailed(info: NsdServiceInfo, error: Int) {}

                            override fun onServiceResolved(info: NsdServiceInfo) {
                                foundHost = info.host.hostAddress
                                foundPort = info.port
                                runOnUiThread {
                                    status.text = "Found ${info.serviceName}: $foundHost:$foundPort"
                                    ipInput.setText(foundHost)
                                    scanButton.isEnabled = true
                                }
                            }
                        })
                    }
                }

                override fun onServiceLost(service: NsdServiceInfo) {}
                override fun onDiscoveryStopped(type: String) {}

                override fun onStartDiscoveryFailed(type: String, error: Int) {
                    runOnUiThread {
                        status.text = "Discovery failed ($error). Enter TV IP manually."
                        scanButton.isEnabled = true
                    }
                    stopDiscovery()
                }

                override fun onStopDiscoveryFailed(type: String, error: Int) {
                    stopDiscovery()
                }
            }

            nsd?.discoverServices("_tvlink._tcp.", NsdManager.PROTOCOL_DNS_SD, discovery)

            android.os.Handler(mainLooper).postDelayed({
                if (role == "controller" && !scanButton.isEnabled) {
                    scanButton.isEnabled = true
                    if (foundHost == null) {
                        status.text = "No TV found. Check same Wi-Fi or enter IP manually."
                    }
                }
            }, 8000)

        } catch (e: Exception) {
            status.text = "Discovery unavailable: ${e.message}"
            scanButton.isEnabled = true
        }
    }

    private fun pair(host: String, code: String) {
        status.text = "Connecting…"
        io.execute {
            var conn: HttpURLConnection? = null
            try {
                val port = if (host == foundHost) foundPort else 8765
                conn = URL("http://$host:$port/pair").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use {
                    it.write(JSONObject().put("code", code).toString().toByteArray())
                }
                val response = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val json = response?.bufferedReader()?.use { it.readText() } ?: "{}"
                val ok = JSONObject(json).optBoolean("ok")
                conn.disconnect()

                runOnUiThread {
                    if (ok) {
                        pairedHost = host
                        pairedPort = port
                        status.text = "Paired successfully ✓ Choose a video to send to TV."
                        videoButton.isEnabled = true
                    } else {
                        status.text = "Pairing failed: invalid code"
                        videoButton.isEnabled = false
                    }
                }
            } catch (e: Exception) {
                conn?.disconnect()
                runOnUiThread {
                    status.text = "Could not connect: ${e.message}. Check IP and Wi-Fi."
                }
            }
        }
    }

    private fun chooseVideo() {
        if (pairedHost == null) {
            status.text = "Connect to your TV first."
            return
        }
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivityForResult(intent, PICK_VIDEO_REQUEST)
    }

    @Deprecated("Deprecated by Android; retained for compatibility with this project's simple Activity flow")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_VIDEO_REQUEST && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            uploadSelectedVideo(uri)
        }
    }

    private fun uploadSelectedVideo(uri: Uri) {
        val host = pairedHost ?: return
        val port = pairedPort
        status.text = "Preparing video…"
        videoButton.isEnabled = false

        io.execute {
            var conn: HttpURLConnection? = null
            var temp: File? = null
            try {
                val displayName = contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index >= 0 && cursor.moveToFirst()) cursor.getString(index) else null
                } ?: "video.mp4"
                val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80).ifBlank { "video.mp4" }
                val uploadFile = File(cacheDir, "tvlink-send-$safeName")
                temp = uploadFile
                contentResolver.openInputStream(uri).use { input ->
                    requireNotNull(input) { "Cannot open selected video" }
                    uploadFile.outputStream().buffered().use { output -> input.copyTo(output) }
                }

                runOnUiThread { status.text = "Sending ${uploadFile.length() / (1024 * 1024)} MB to TV…" }

                conn = URL("http://$host:$port/upload").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 15000
                conn.readTimeout = 600000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/octet-stream")
                conn.setRequestProperty("X-File-Name", safeName)
                // Send the video as a raw binary request body. This avoids NanoHTTPD's
                // multipart parser, which can fail on certain payload boundaries.
                conn.setFixedLengthStreamingMode(uploadFile.length())
                uploadFile.inputStream().buffered(64 * 1024).use { input ->
                    conn.outputStream.buffered(64 * 1024).use { output ->
                        val buffer = ByteArray(64 * 1024)
                        while (true) {
                            val count = input.read(buffer)
                            if (count < 0) break
                            output.write(buffer, 0, count)
                        }
                        output.flush()
                    }
                }

                val response = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val json = response?.bufferedReader()?.use { it.readText() } ?: "{}"
                val result = JSONObject(json)
                if (!result.optBoolean("ok")) throw Exception(result.optString("error", "Upload failed"))
                conn.disconnect()

                runOnUiThread { status.text = "Video sent successfully ✓ It should now play on your TV." }
            } catch (e: Exception) {
                conn?.disconnect()
                runOnUiThread { status.text = "Video sending failed: ${e.message}" }
            } finally {
                temp?.delete()
                runOnUiThread { videoButton.isEnabled = true }
            }
        }
    }

    private fun sendControl(action: String) {
        val host = pairedHost
        if (host == null) {
            status.text = "Connect to your TV first."
            return
        }
        val port = pairedPort
        io.execute {
            var conn: HttpURLConnection? = null
            try {
                conn = URL("http://$host:$port/control").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.connectTimeout = 4000
                conn.readTimeout = 4000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                conn.outputStream.use {
                    it.write(JSONObject().put("action", action).toString().toByteArray())
                }
                val ok = conn.responseCode in 200..299
                conn.disconnect()
                runOnUiThread { status.text = if (ok) "TV command sent: $action" else "Could not send TV command." }
            } catch (e: Exception) {
                conn?.disconnect()
                runOnUiThread { status.text = "Remote command failed: ${e.message}" }
            }
        }
    }

    private fun registerService(port: Int) {
        val info = NsdServiceInfo().apply {
            serviceName = "TVLink-${android.os.Build.MODEL.replace(" ", "-")}"
            serviceType = "_tvlink._tcp."
            setPort(port)
        }
        registration = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(info: NsdServiceInfo) {}
            override fun onRegistrationFailed(info: NsdServiceInfo, error: Int) {}
            override fun onServiceUnregistered(info: NsdServiceInfo) {}
            override fun onUnregistrationFailed(info: NsdServiceInfo, error: Int) {}
        }
        nsd?.registerService(info, NsdManager.PROTOCOL_DNS_SD, registration)
    }

    /** Returns the active LAN IPv4 address for Wi-Fi or Ethernet connections. */
    private fun localIp(): String = try {
        val addresses = java.net.NetworkInterface.getNetworkInterfaces()
        val candidates = mutableListOf<String>()
        while (addresses.hasMoreElements()) {
            val network = addresses.nextElement()
            if (!network.isUp || network.isLoopback) continue
            val ips = network.inetAddresses
            while (ips.hasMoreElements()) {
                val address = ips.nextElement()
                if (address is java.net.Inet4Address && !address.isLoopbackAddress && !address.isLinkLocalAddress) {
                    candidates.add(address.hostAddress ?: continue)
                }
            }
        }
        // Prefer common private LAN addresses; otherwise show the first usable IPv4.
        candidates.firstOrNull { it.startsWith("192.168.") || it.startsWith("10.") ||
            (it.startsWith("172.") && (it.substringAfter("172.").substringBefore('.').toIntOrNull()?.let { octet -> octet in 16..31 } == true)) }
            ?: candidates.firstOrNull() ?: "TV_IP"
    } catch (_: Exception) {
        "TV_IP"
    }

    private fun stopDiscovery() {
        try { discovery?.let { nsd?.stopServiceDiscovery(it) } } catch (_: Exception) {}
        discovery = null
        try { lock?.release() } catch (_: Exception) {}
        lock = null
    }

    private fun stopNetwork() {
        stopDiscovery()
        try { registration?.let { nsd?.unregisterService(it) } } catch (_: Exception) {}
        registration = null
        try { server?.stop() } catch (_: Exception) {}
        server = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun errorScreen(s: String) {
        root = column()
        root.addView(label("TVLink error", 25f, true))
        root.addView(label(s, 16f))
        root.addView(button("Back") { home() })
        showPage()
    }

    /** TV layout must use the real screen height: a ScrollView measures weighted children as zero-height. */
    private fun showTvPage() {
        root.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        )
        root.isFocusableInTouchMode = true
        setContentView(root)
        tvVideo?.requestFocus()
    }

    /** Displays phone screens inside a vertical scroll container so small phones can reach all controls. */
    private fun showPage() {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = true
            setBackgroundColor(android.graphics.Color.rgb(16, 17, 20))
            clipToPadding = false
        }
        root.layoutParams = ScrollView.LayoutParams(
            ScrollView.LayoutParams.MATCH_PARENT,
            ScrollView.LayoutParams.WRAP_CONTENT
        )
        scroll.addView(root, ScrollView.LayoutParams(
            ScrollView.LayoutParams.MATCH_PARENT,
            ScrollView.LayoutParams.WRAP_CONTENT
        ))
        setContentView(scroll)
    }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val horizontalPadding = (resources.displayMetrics.widthPixels / resources.displayMetrics.density * 0.05f)
            .toInt().coerceIn(16, 28)
        setPadding(horizontalPadding, 16, horizontalPadding, 20)
        gravity = Gravity.TOP
        setBackgroundColor(android.graphics.Color.rgb(16, 17, 20))
    }

    private fun label(s: String, size: Float, bold: Boolean = false) =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(android.graphics.Color.WHITE)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 8, 0, 12)
        }

    private fun button(s: String, action: () -> Unit) =
        Button(this).apply {
            text = s
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = 4; bottomMargin = 4 }
        }

    override fun onDestroy() {
        stopNetwork()
        io.shutdownNow()
        super.onDestroy()
    }
}

data class PairingState(
    val code: String,
    @Volatile var paired: Boolean = false
)

class TvHttpServer(
    port: Int,
    private val state: PairingState,
    private val assetManager: android.content.res.AssetManager,
    private val cacheDir: File,
    private val onVideoReceived: (File) -> Unit,
    private val onControl: (String) -> Unit
) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        val origin = session.headers["origin"]
        val cors = mapOf(
            "Access-Control-Allow-Origin" to (origin ?: "*"),
            "Access-Control-Allow-Methods" to "GET, POST, OPTIONS",
            "Access-Control-Allow-Headers" to "Content-Type, X-File-Name",
            "Cache-Control" to "no-store"
        )
        if (session.method == Method.OPTIONS) {
            return response(Response.Status.OK, "text/plain", "", cors)
        }

        return try {
            when (session.uri) {
                "/" -> response(
                    Response.Status.OK,
                    "text/html; charset=utf-8",
                    assetManager.open("web/index.html").bufferedReader().use { it.readText() },
                    emptyMap()
                )
                "/health" -> json(JSONObject().put("ok", true), cors)
                "/info" -> json(
                    JSONObject().put("name", "TVLink Receiver").put("port", 8765).put("paired", state.paired),
                    cors
                )
                "/status" -> json(JSONObject().put("paired", state.paired), cors)
                "/pair" -> {
                    if (session.method != Method.POST) {
                        json(JSONObject().put("ok", false).put("error", "POST required"), cors, Response.Status.METHOD_NOT_ALLOWED)
                    } else {
                        val files = HashMap<String, String>()
                        session.parseBody(files)
                        val body = JSONObject(files["postData"] ?: "{}")
                        if (body.optString("code") == state.code) {
                            state.paired = true
                            json(JSONObject().put("ok", true).put("message", "paired"), cors)
                        } else {
                            json(JSONObject().put("ok", false).put("error", "invalid code"), cors, Response.Status.UNAUTHORIZED)
                        }
                    }
                }
                "/upload" -> {
                    if (session.method != Method.POST) {
                        json(JSONObject().put("ok", false).put("error", "POST required"), cors, Response.Status.METHOD_NOT_ALLOWED)
                    } else if (!state.paired) {
                        json(JSONObject().put("ok", false).put("error", "Pair with TV first"), cors, Response.Status.UNAUTHORIZED)
                    } else {
                        val contentType = session.headers["content-type"].orEmpty()
                        if (contentType.startsWith("multipart/form-data", ignoreCase = true)) {
                            throw IllegalArgumentException("Please update the phone app: raw binary upload is required")
                        }
                        val expectedLength = session.headers["content-length"]?.toLongOrNull()
                            ?: throw IllegalArgumentException("Missing Content-Length header")
                        if (expectedLength <= 0L) throw IllegalArgumentException("The selected video is empty")

                        val rawName = session.headers["x-file-name"] ?: "received-video.mp4"
                        val extension = rawName.substringAfterLast('.', "mp4")
                            .lowercase(Locale.US).filter { it.isLetterOrDigit() }.take(8).ifBlank { "mp4" }
                        val destination = File(cacheDir, "tvlink-received-video.$extension")
                        val partial = File(cacheDir, "tvlink-received-video.$extension.part")
                        var received = 0L
                        try {
                            // NanoHTTPD has already buffered the socket stream. Read that
                            // stream directly to avoid an extra buffer prefetching bytes
                            // belonging to a keep-alive request after this upload.
                            val input = session.inputStream
                            partial.outputStream().buffered(64 * 1024).use { output ->
                                    val buffer = ByteArray(64 * 1024)
                                    while (received < expectedLength) {
                                        val wanted = minOf(buffer.size.toLong(), expectedLength - received).toInt()
                                        val count = input.read(buffer, 0, wanted)
                                        if (count < 0) throw IllegalArgumentException("Video upload ended early ($received/$expectedLength bytes)")
                                        output.write(buffer, 0, count)
                                        received += count
                                    }
                                    output.flush()
                            }
                            if (received != expectedLength || partial.length() != expectedLength) {
                                throw IllegalArgumentException("Incomplete video upload ($received/$expectedLength bytes)")
                            }
                            if (destination.exists() && !destination.delete()) {
                                throw IllegalStateException("Could not replace previous video")
                            }
                            if (!partial.renameTo(destination)) {
                                partial.copyTo(destination, overwrite = true)
                                partial.delete()
                            }
                        } catch (e: Exception) {
                            partial.delete()
                            throw e
                        }
                        onVideoReceived(destination)
                        json(
                            JSONObject().put("ok", true).put("name", destination.name).put("bytes", destination.length()),
                            cors
                        )
                    }
                }
                "/control" -> {
                    if (session.method != Method.POST) {
                        json(JSONObject().put("ok", false).put("error", "POST required"), cors, Response.Status.METHOD_NOT_ALLOWED)
                    } else if (!state.paired) {
                        json(JSONObject().put("ok", false).put("error", "Pair with TV first"), cors, Response.Status.UNAUTHORIZED)
                    } else {
                        val files = HashMap<String, String>()
                        session.parseBody(files)
                        val action = JSONObject(files["postData"] ?: "{}").optString("action")
                        if (action !in setOf("play", "pause", "stop")) {
                            json(JSONObject().put("ok", false).put("error", "Unknown action"), cors, Response.Status.BAD_REQUEST)
                        } else {
                            onControl(action)
                            json(JSONObject().put("ok", true), cors)
                        }
                    }
                }
                else -> response(Response.Status.NOT_FOUND, "text/plain", "Not found", emptyMap())
            }
        } catch (e: Exception) {
            json(
                JSONObject().put("ok", false).put("error", e.message ?: "request failed"),
                cors,
                Response.Status.INTERNAL_ERROR
            )
        }
    }

    private fun json(obj: JSONObject, headers: Map<String, String>, status: Response.Status = Response.Status.OK) =
        response(status, "application/json; charset=utf-8", obj.toString(), headers)

    private fun response(status: Response.Status, mime: String, body: String, headers: Map<String, String>) =
        newFixedLengthResponse(status, mime, body).also { r -> headers.forEach { (k, v) -> r.addHeader(k, v) } }
}
