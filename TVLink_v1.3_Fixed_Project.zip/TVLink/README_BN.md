# TVLink Android Project — Phone to TV video transfer

## এই সংস্করণে যা আছে
- TV Box mode চালু করলে TV-তে ৬ সংখ্যার Pairing Code এবং IP address দেখায়।
- Android Controller থেকে একই Wi-Fi নেটওয়ার্কে TVLink receiver খোঁজা যায়; না পেলে IP হাতে লেখা যায়।
- ৬ সংখ্যার কোড দিয়ে Pair করার পর ফোনের Gallery / Files থেকে ভিডিও নির্বাচন করা যায়।
- নির্বাচিত ভিডিও Wi-Fi দিয়ে TV Box-এ আপলোড হয় এবং TV-তে VideoView দিয়ে চালু হয়।
- ফোন থেকে Play / Resume, Pause এবং Stop কমান্ড পাঠানো যায়।
- TV Box-এর স্ক্রিনে স্থানীয় Play, Pause এবং Stop বোতামও আছে।

## ব্যবহার করার নিয়ম
1. একই TVLink APK Android TV Box এবং Android Phone—দুই ডিভাইসেই ইনস্টল করুন।
2. দুই ডিভাইসকে একই Wi-Fi নেটওয়ার্কে যুক্ত করুন। Guest Wi-Fi বা client isolation চালু থাকলে কাজ নাও করতে পারে।
3. TV Box-এ TVLink খুলে **TV Box mode — show pairing code** নির্বাচন করুন। TV স্ক্রিনে ৬ সংখ্যার কোড ও IP address থাকবে। এই স্ক্রিন খোলা রাখুন।
4. ফোনে TVLink খুলে **Android Controller — find TV** নির্বাচন করুন।
5. **Scan for TVs** চাপুন। TV না পেলে TV স্ক্রিনে দেখানো IP address হাতে লিখুন।
6. TV-এর ৬ সংখ্যার কোড লিখে **Connect** চাপুন।
7. Pair সফল হলে **Choose video from phone** চাপুন এবং ফোনের Gallery / Files থেকে ভিডিও নির্বাচন করুন।
8. আপলোড শেষ হলে ভিডিও TV-তে চালু হবে। ফোনের Play / Resume, Pause ও Stop বোতাম দিয়ে নিয়ন্ত্রণ করুন।

## Build করার নিয়ম (Windows CMD)
JDK 17 এবং Android SDK Platform 35 ইনস্টল থাকতে হবে। `local.properties`-এ আপনার কম্পিউটারের Android SDK path ঠিক আছে কি না দেখুন।

```bat
gradlew.bat assembleDebug
```

APK:
`app\build\outputs\apk\debug\app-debug.apk`

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- ফোন ও TV Box-এ একই TVLink অ্যাপ ইনস্টল থাকতে হবে।
- TVLink অ্যাপ TV Box-এ খোলা রাখতে হবে; এই সংস্করণে ব্যাকগ্রাউন্ড receiver service নেই।
- ভিডিও সরাসরি TV Box-এ কপি হয়; বড় ভিডিও পাঠাতে সময় লাগবে এবং TV Box-এ যথেষ্ট ফাঁকা জায়গা থাকতে হবে।
- MP4 (H.264/AAC) সাধারণত সবচেয়ে ভালো সামঞ্জস্য দেয়। অন্য ফরম্যাট TV Box-এর নিজস্ব Android codec সমর্থনের ওপর নির্ভর করে।
- এটি YouTube casting নয়; ফোনে থাকা লোকাল ভিডিও ফাইল TV-তে পাঠায়।
- Android TV Box-এর ফাইল/ভিডিও প্লেব্যাক সামর্থ্য এবং Wi-Fi নেটওয়ার্কের ওপর ফলাফল নির্ভর করবে।


## ভিডিও পাঠানোর ত্রুটি সংশোধন
- ফোন থেকে TV-তে পাঠানোর multipart/form-data request-এর header-এ সঠিক CRLF line ending ব্যবহার করা হয়েছে।
- আগের সোর্সে `\\r\\n` literal text পাঠানো হচ্ছিল; এতে TV receiver-এর multipart parser ভুলভাবে ডেটা পড়তে পারত এবং 1024-byte buffer boundary-তে crash করতে পারত।


## ভিডিও আপলোড ও ফোন UI সংশোধন (v1.2)
- ফোন থেকে ভিডিও এখন `application/octet-stream` raw binary body হিসেবে পাঠানো হয়; multipart upload ব্যবহার করা হয় না।
- TV Receiver `Content-Length` অনুযায়ী 64 KB buffer-এ নির্দিষ্ট সংখ্যক byte গ্রহণ করে এবং সম্পূর্ণ ফাইল না এলে partial file মুছে ফেলে।
- ফোনের পেজ ScrollView-তে থাকে; কিবোর্ড উঠলেও স্ক্রিনের নিচের কন্ট্রোল স্ক্রল করে ব্যবহার করা যায়।
- Orientation system auto (portrait/landscape); orientation বদলালে Activity restart হয়ে TV receiver বন্ধ হয় না।
- IP ও PIN TextBox সাদা background, কালো লেখা এবং গাঢ় hint text ব্যবহার করে।

**গুরুত্বপূর্ণ:** ফোন এবং TV—দুই ডিভাইসেই একই v1.2 APK ইনস্টল করতে হবে, কারণ upload protocol পরিবর্তন করা হয়েছে।


## TVLink v1.3 — TV স্ক্রিন ও নেটওয়ার্ক IP সংশোধন
- TV Box স্ক্রিন এখন ScrollView-এর ভিতরে নয়; সরাসরি পূর্ণ-স্ক্রিন layout ব্যবহার করে। এতে VideoView-এর `weight=1` সঠিকভাবে জায়গা পায় এবং ভিডিও দেখানোর ক্ষেত্র শূন্য-উচ্চতার হওয়ার সমস্যা এড়ানো হয়।
- TV-এর Play / Pause / Stop বোতাম একই সারিতে রাখা হয়েছে, যাতে ভিডিওর জন্য বেশি জায়গা থাকে।
- TV IP খোঁজার সময় শুধু Wi-Fi-এর পুরোনো `WifiInfo.ipAddress` নয়; সক্রিয় নেটওয়ার্ক ইন্টারফেসের IPv4 address দেখা হয়। এতে Ethernet-যুক্ত TV Box-এও LAN IP দেখানোর সম্ভাবনা বাড়ে।
- Version: 1.3 (versionCode 4)।

### Build যাচাই সম্পর্কে
এই ZIP-এ Gradle Wrapper এবং Android project configuration রয়েছে। Build করতে JDK 17 এবং Android SDK Platform 35 ইনস্টল থাকতে হবে। প্রথম Build-এ ইন্টারনেট সংযোগ লাগতে পারে, কারণ Gradle dependency ডাউনলোড হতে পারে। Build সফল হয়েছে কি না তা আপনার Windows কম্পিউটারে নিচের কমান্ড চালিয়ে নিশ্চিত করুন:

```bat
cd /d C:\Users\YOURNAME\Desktop\TVLink
gradlew.bat clean assembleDebug
```

APK তৈরি হলে ফাইলটি থাকবে `app\build\outputs\apk\debug\app-debug.apk`-এ। ফোন ও TV—দুই জায়গায় একই v1.3 APK ইনস্টল করুন।
